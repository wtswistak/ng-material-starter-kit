export interface JobTagsModel {
  readonly name: string;
}
