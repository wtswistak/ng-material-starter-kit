export interface JobsGridModel {
  readonly title: string;
  readonly description:string;
}
