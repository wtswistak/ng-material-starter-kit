export interface ProductModel {
  readonly title: string;
  readonly price:string;
  readonly image:string;
  readonly category:string;
}
