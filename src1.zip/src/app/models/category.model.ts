export interface CategoryModel {
}
