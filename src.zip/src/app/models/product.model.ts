export interface ProductModel {
  readonly title: string;
}
